package renombrar;



public class Renombrar {
	public int devolverMayor (int num1,int num2) {
		int resultado;
		if (num1>num2) {
			resultado=num1;
		}
		else {
			resultado=num2;
		}
		return resultado;
	}
}

